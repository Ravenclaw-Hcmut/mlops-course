# Stream emitting

```bash
# start stream emitting service
bash deploy.sh start

# stop stream emitting service
bash deploy.sh stop

# teardown stream emitting service
bash deploy.sh teardown
```