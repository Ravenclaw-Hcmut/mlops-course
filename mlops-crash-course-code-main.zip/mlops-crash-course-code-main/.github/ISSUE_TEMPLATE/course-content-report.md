---
name: Course content report
about: Đóng góp ý kiến về nội dung của một khoá học
title: "[COURSE]"
labels: documentation
assignees: ""
---

**Khoá học**

-   Tên khoá học
-   Tên bài trong khoá học

## 1. Tên lỗi, hoặc tên bài, hoặc tên phần trong bài

-   Ảnh chụp đoạn cần chỉnh sửa trong bài
-   Mô tả lỗi hay đóng góp ý kiến về một phần trong bài
-   Giải pháp/cách sửa (nếu có)

## 2. Tên lỗi, hoặc tên bài, hoặc tên phần trong bài
