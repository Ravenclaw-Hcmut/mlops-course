---
name: Bug report
about: Create a report to help us improve
title: "[BUG]"
labels: bug
assignees: ""
---

**Mô tả bug**

-   Tên bug
-   Link tới bài
-   Xảy ra ở bước (ảnh ở bước xảy ra bug trong bài)

**Cách tạo lại bug**

1. Đi tới ABC
2. Click ABC
3. Kéo xuống phần ABC
4. Xuất hiện lỗi ABC

**Expected behaviors**

Mô tả đầu ra/hành vi mong muốn thay vì bug

**Attachments**

Đính kèm lỗi dạng ảnh hoặc dạng text

**Specs**

-   Software: thông tin về version của docker, docker-compose, software tools, etc.
-   System: thông tin về OS, CPU, Memory, GPU, etc.

**Additional context**

Bất kì điều gì khác
