# mlops-crash-course-code

## Requirements

```bash
Docker version 20.10.17, build 100c701
Docker Compose version v2.10.2
```

Tested on OS:

-   Ubuntu 20.04
-   MacOS using M1, M2, Intel CPU
